# bag_to_df
A library converting a ROS2 .db3 file to pandas df 
